<section class="qualifications-section">
    <div class="container qualifications-content">
        <div class="qualifications-title-wrap">
            <h2 class="qualifications-title">Other</h2>
        </div>
        <div class="qualifications-list">
            <span class="qual-item">Driving license class B, D1</span>
            <span class="separator">|</span>
            <span class="qual-item">Forklift T1, T2 og T4</span>
            <span class="separator">|</span>
            <span class="qual-item">Båtførerprøven</span>
        </div>
    </div>
</section>