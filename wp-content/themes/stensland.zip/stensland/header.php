<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

    <header class="site-header">
        <div class="container header-container">
            <div class="site-branding">
                <?php
                if (has_custom_logo()) {
                    the_custom_logo();
                } else {
                    echo '<a href="' . esc_url(home_url('/')) . '" rel="home">';
                    echo '<img src="' . get_template_directory_uri() . '/assets/images/logo.png" alt="' . get_bloginfo('name') . '">'; // Assuming logo is an SVG
                    echo '</a>';
                }
                ?>
            </div>
            <nav class="site-navigation">
                <div class="lang-selector">
                    EN <span class="arrow-down">&#9660;</span>
                </div>
                <a href="#" class="button-primary">Book a Call <span class="arrow-up-right">&#8599;</span></a>
            </nav>
        </div>
    </header>

    <div id="page" class="site">
        <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e('Skip to content', 'textdomain'); ?></a>