<?php
get_header();
?>

<main id="main-content">
    <?php
    // Example sections — we’ll add them one by one
    get_template_part('template-parts/sections/hero');
    get_template_part('template-parts/sections/qualifications');

    get_template_part('template-parts/sections/about');
    get_template_part('template-parts/sections/features');
    get_template_part('template-parts/sections/contact');

    ?>
</main>

<?php
get_footer();
?>
